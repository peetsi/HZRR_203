def vorlaut( rang, s):
  # rang: 9 high, 0 low
  # gib nur Werte mit einem mindestrang aus
  rang_min = 0
  if rang >= rang_min:
    print(s)